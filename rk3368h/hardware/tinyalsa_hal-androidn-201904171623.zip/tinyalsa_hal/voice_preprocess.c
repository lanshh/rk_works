/*
 * Copyright (C) 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file    voice_preprocess.c
 * @author  Sun Mingjun <smj@rock-chips.com>
 * @date    2017-05-08
 */

#define LOG_NDEBUG 0

#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/time.h>
#include <dlfcn.h>  // for dlopen/dlclose
#include <fcntl.h>

#include <cutils/log.h>
#include <cutils/properties.h>
#include <cutils/str_parms.h>

#include <speex/speex.h>
#include <speex/speex_preprocess.h>
#include <speex/speex_resampler.h>


#include "voice_preprocess.h"

#define LOG_TAG "voice_process"

#define ALOGD_3A(fmt, args...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, fmt, ##args)
#define RK_3A_RATE 16000

#define PLUGINS_PATH "/vendor/lib/hw/"
#define PARAM_PATH "/vendor/etc/"

#if (RK_3A_RATE == 8000)
#define PROCESS_BUFFER_SIZE (128)
#define RK_3A_CHANNEL 1
#elif (RK_3A_RATE == 16000)
#define PROCESS_BUFFER_SIZE (256)
#define RK_3A_CHANNEL 1
#else
#error "defined sample rate is no supported by rk 3a"
#endif

#define MAX_BUFFER_SIZE (500 * 1024)
#define false (0)
#define true  (1)
#define bool  int

#define ALSA_3A_DEBUG
#ifdef ALSA_3A_DEBUG
FILE *in_capture_debug;
FILE *out_capture_debug;
FILE *in_playback_debug;
FILE *out_playback_debug;
#endif

typedef struct voiceThread_t_ {
    bool            running;
    pthread_t       thread;
    sem_t           sem;
    int             threadStatus;
    pthread_mutex_t queueCapLock;
    pthread_mutex_t queuePlyLock;
    pthread_mutex_t getCapOutLock;
    pthread_mutex_t getPlyOutLock;
} voiceThread_t;

typedef int(*PFNGETERR)(char *para, int size);
typedef int(*PFNINIT)(char *para);
typedef void(*PFNTX)(short  *in, short *ref, short *out, int len);
typedef void(*PFNRX)(short *in, short *out, int len);
typedef void(*PFNDEINIT)();

typedef struct rk_voice_api_ {
    PFNGETERR lasterror;
    PFNINIT init;
    PFNTX processCapture;
    PFNRX processPlayback;
    PFNDEINIT deinit;
} rk_voice_api;


typedef struct rk_voice_handle_ {
    int     init;
    void*   voiceLibHandle;
    rk_voice_api *voiceApi;
    rk_process_api *processApi;
    char*  playBackBuffer;
    char*  captureBuffer;
    char*  outPlayBuffer;
    char*  outCaptureBuffer;
    SpeexResamplerState* speexCapureDownResample;
    SpeexResamplerState* speexCapureUpResample;
    SpeexResamplerState* speexPlaybackDownResample;
    SpeexResamplerState* speexPlaybackUpResample;
    voiceThread_t voice_thread;
    int    playbackBufferSize;
    int    captureBufferSize;
    int    outPlaybackBufferSize;
    int    outCaptureBufferSize;
    int    captureInSamplerate;
    int    processSamplerate;
    int    playbackInSamplerate;
    int    captureInChannels;
    int    processChannels;
    int    playbackInChannels;
    int    processBuffersize;
    int    minPlaybackBuffersize;
    int    minCaptureBuffersize;

    /* buffer count needed be processed */
    int nPlaybackExtFrameCount;
    int nCauptureExtFrameCount;

    int nProcessFrameCount;
    int nProcessFrameSize;
    int nProcessChannelCount;
} rk_voice_handle;

static rk_voice_handle rk_3a_context = {0};
static int prop_pcm_record = 0;

static void thread_loop(rk_voice_handle* handle);
static void*  thread_start(void* argv);
static void dump_out_data(const void* buffer,size_t bytes, int *size)
{
    static FILE* fd = NULL;
    static int offset = 0;
    if(fd == NULL) {
        fd=fopen("/data/1.pcm","wb+");
        if(fd == NULL) {
            ALOGD("DEBUG open  error =%d ,errno = %d",fd,errno);
            offset = 0;
        }
    }
    fwrite(buffer,bytes,1,fd);
    offset += bytes;
    fflush(fd);
    if(offset >= (*size)*1024*1024) {
        *size = 0;
        fclose(fd);
        offset = 0;
    }
}

static inline rk_voice_handle* getHandle()
{
    return &rk_3a_context;
}

static int start()
{
    rk_voice_handle *pHandle = getHandle();

    if (!pHandle->init) {
        return -1;
    }
    if (pHandle->voice_thread.threadStatus >= 0) {
        return -1;
    }
    sem_init(&pHandle->voice_thread.sem, 0, 1);
    pHandle->voice_thread.running = true;
    if (pHandle->voice_thread.threadStatus == -1)
        pHandle->voice_thread.threadStatus = pthread_create(&pHandle->voice_thread.thread, NULL, thread_start, pHandle);
    ALOGD("voice process start !, ret = %d", pHandle->voice_thread.threadStatus);
    return 0;
}

static int queueCaputureBuffer(void *buf, int size)
{
    rk_voice_handle *pHandle = getHandle();

    if (pHandle->playbackBufferSize <= 0) {
        ALOGV("not queue capture buffer until playback buffer queued");
        return -1;
    }
    pthread_mutex_lock(&pHandle->voice_thread.queueCapLock);
    if (pHandle->captureBuffer) {
        if (pHandle->captureBufferSize + size >= MAX_BUFFER_SIZE) {
            ALOGW("capture buffer size out of range, flush");
            memset(pHandle->captureBuffer, 0x00, MAX_BUFFER_SIZE);
            pHandle->captureBufferSize = 0;
        }
        memcpy((char *)pHandle->captureBuffer + pHandle->captureBufferSize, (char *)buf, size);
        pHandle->captureBufferSize += size;
    }
    pthread_mutex_unlock(&pHandle->voice_thread.queueCapLock);

    if ((pHandle->captureBufferSize >= pHandle->minCaptureBuffersize) 
        && (pHandle->playbackBufferSize >= pHandle->minPlaybackBuffersize)) {
        sem_post(&pHandle->voice_thread.sem);
    }
    return 0;
}

static int queuePlaybackBuffer(void *buf, int size)
{
    rk_voice_handle *pHandle = getHandle();

    pthread_mutex_lock(&pHandle->voice_thread.queuePlyLock);
    if (pHandle->playbackBufferSize + size >= MAX_BUFFER_SIZE) {
        ALOGW("capture buffer size out of range, flush");
        memset(pHandle->playBackBuffer, 0x00, MAX_BUFFER_SIZE);
        pHandle->playbackBufferSize = 0;
    }
    memcpy((char *)pHandle->playBackBuffer+ pHandle->playbackBufferSize, (char *)buf, size);
    pHandle->playbackBufferSize+= size;
    pthread_mutex_unlock(&pHandle->voice_thread.queuePlyLock);

    if ((pHandle->captureBufferSize >= pHandle->minCaptureBuffersize)
        && (pHandle->playbackBufferSize >= pHandle->minPlaybackBuffersize)) {
        sem_post(&pHandle->voice_thread.sem);
    }
    return 0;
}

static int getCapureBuffer(void *buf, int size)
{
    rk_voice_handle *pHandle = getHandle();

    if (pHandle->outCaptureBufferSize < size) {
        ALOGW("cannot get caputre buffer currently, try next time %d", pHandle->outCaptureBufferSize);
        return -1;
    }
    pthread_mutex_lock(&pHandle->voice_thread.getCapOutLock);
    if (pHandle->outCaptureBuffer) {
        memcpy((char *)buf, pHandle->outCaptureBuffer, size);
        memcpy(pHandle->outCaptureBuffer, pHandle->outCaptureBuffer+size, MAX_BUFFER_SIZE - size);
        pHandle->outCaptureBufferSize -= size;
    }
    pthread_mutex_unlock(&pHandle->voice_thread.getCapOutLock);
    return 0;
}

static int getPlaybackBuffer(void *buf, int size)
{
    rk_voice_handle *pHandle = getHandle();

    if (pHandle->outPlaybackBufferSize < size) {
        ALOGW("cannot get playback buffer currently, try next time");
        return -1;
    }
    pthread_mutex_lock(&pHandle->voice_thread.getPlyOutLock);
    if (pHandle->outPlayBuffer) {
        memcpy((char *)buf, (char *)pHandle->outPlayBuffer, size);
        memcpy((char *)pHandle->outPlayBuffer, (char *)pHandle->outPlayBuffer+size, MAX_BUFFER_SIZE - size);
        pHandle->outPlaybackBufferSize -= size;
    }
    pthread_mutex_unlock(&pHandle->voice_thread.getPlyOutLock);

    return 0;
}

static int flush()
{
    rk_voice_handle* pHandle = getHandle();

    pthread_mutex_lock(&pHandle->voice_thread.queuePlyLock);
    if (pHandle->playBackBuffer) {
        memset((char *)pHandle->playBackBuffer, 0x00, MAX_BUFFER_SIZE);
        pHandle->playbackBufferSize = 0;
    }
    pthread_mutex_unlock(&pHandle->voice_thread.queuePlyLock);

    pthread_mutex_lock(&pHandle->voice_thread.queueCapLock);
    if (pHandle->playBackBuffer) {
        memset((char *)pHandle->captureBuffer, 0x00, MAX_BUFFER_SIZE);
        pHandle->captureBufferSize = 0;
    }
    pthread_mutex_unlock(&pHandle->voice_thread.queueCapLock);

    return 0;
}


rk_process_api* rk_voiceprocess_create(int ply_sr, int ply_ch, int cap_sr, int cap_ch)
{
    rk_voice_handle *pHandle;
    char plugin_path[128];
    char param_path[128];
    char  error_buf[256] = {0};

    if (rk_3a_context.init) {
        ALOGW("rk 3a context has already init, exit");
        return rk_3a_context.processApi;
    }
	sprintf(plugin_path, "%s%s", PLUGINS_PATH, "libvoiceprocess.so");
	if(access(plugin_path, 0)) {
		ALOGE("rk 3a context plugin %s can not access, exit", plugin_path);
		return NULL;
	}
	sprintf(param_path, "%s%s", PARAM_PATH, "RK_VoicePara.bin");
	if(access(param_path, 0)) {
		ALOGE("rk 3a context parameter %s can not access, exit", param_path);
		return NULL;
	}
    pHandle = &rk_3a_context;

    pHandle->voiceLibHandle        = NULL;
    pHandle->voiceApi              = NULL;
    pHandle->processApi            = NULL;
    pHandle->playBackBuffer        = NULL;
    pHandle->captureBuffer         = NULL;
    pHandle->speexCapureDownResample   = NULL;
    pHandle->speexCapureUpResample     = NULL;
    pHandle->speexPlaybackDownResample = NULL;
    pHandle->speexPlaybackUpResample   = NULL;
    pHandle->playbackBufferSize     = 0;
    pHandle->captureBufferSize      = 0;
    pHandle->outPlaybackBufferSize  = 0;
    pHandle->outCaptureBufferSize   = 0;

    pHandle->captureInSamplerate    = cap_sr;
    pHandle->captureInChannels      = cap_ch;

    pHandle->playbackInSamplerate   = ply_sr;
    pHandle->playbackInChannels     = ply_ch;

    pHandle->processSamplerate      = RK_3A_RATE;
    pHandle->processChannels        = RK_3A_CHANNEL;
    pHandle->nProcessFrameSize      = 2;

    /* frame count calc */
    pHandle->nProcessFrameCount = PROCESS_BUFFER_SIZE;
    pHandle->nCauptureExtFrameCount = pHandle->nProcessFrameCount * cap_sr / pHandle->processSamplerate;
    pHandle->nPlaybackExtFrameCount = pHandle->nProcessFrameCount * ply_sr / pHandle->processSamplerate;
    /* frame size calc */
    pHandle->processBuffersize = pHandle->nProcessFrameCount *
                                 pHandle->nProcessFrameSize *
                                 pHandle->processChannels;
    pHandle->minPlaybackBuffersize = pHandle->nPlaybackExtFrameCount * 2 *ply_ch;
    pHandle->minCaptureBuffersize = pHandle->nCauptureExtFrameCount * 2 *ply_ch;
    ALOGD_3A("info plugin       : %s", plugin_path);
    ALOGD_3A("info param        : %s", param_path);
    ALOGD_3A("info capture rate : %d", pHandle->captureInSamplerate);
    ALOGD_3A("info playback rate: %d", pHandle->playbackInSamplerate);
    ALOGD_3A("info process rate : %d", pHandle->processSamplerate);
    ALOGD_3A("info capture frm  : %d", pHandle->nCauptureExtFrameCount);
    ALOGD_3A("info playback frm : %d", pHandle->nPlaybackExtFrameCount);
    ALOGD_3A("info process frm  : %d", pHandle->nProcessFrameCount);
    ALOGD_3A("info capture size : %d", pHandle->minCaptureBuffersize);
    ALOGD_3A("info playback size: %d", pHandle->minPlaybackBuffersize);
    ALOGD_3A("info process size : %d", pHandle->processBuffersize);

    { /* check buffer align */
        float capture_frm, playback_frm, raw_rate, p_rate;

        raw_rate = cap_sr;
        p_rate = pHandle->processSamplerate;
        capture_frm = pHandle->nProcessFrameCount * raw_rate / p_rate;
        raw_rate = ply_sr;
        playback_frm = pHandle->nProcessFrameCount * raw_rate / p_rate;
        ALOGD_3A("info buffer align : capture %s playback %s",
                 capture_frm == pHandle->nCauptureExtFrameCount ? "ok" : "fail",
                 playback_frm == pHandle->nPlaybackExtFrameCount ? "ok" : "fail");
    }

    pHandle->voice_thread.running = false;
    pHandle->voice_thread.threadStatus = -1;

    // open the voice process lib
    pHandle->voiceLibHandle = dlopen(plugin_path, RTLD_LAZY);
    if (pHandle->voiceLibHandle == NULL) {
        ALOGW("dlopen %s error %s!", plugin_path, dlerror());
        goto failed;
    }
    pHandle->voiceApi = (rk_voice_api *)malloc(sizeof(rk_voice_api));
    if (pHandle->voiceApi == NULL) {
        ALOGE("voiceApi malloc error!  return");
        goto failed;
    }
    memset(pHandle->voiceApi, 0, sizeof(rk_voice_api));
    pHandle->voiceApi->lasterror = (PFNGETERR)dlsym(pHandle->voiceLibHandle, "RK_VOICE_GetLastError");
    if (pHandle->voiceApi->lasterror == NULL) {
        ALOGD("dlsym voice process get lasterror fail");
    }

    pHandle->voiceApi->init = (PFNINIT)dlsym(pHandle->voiceLibHandle, "RK_VOICE_Init");
    pHandle->voiceApi->processCapture = (PFNTX)dlsym(pHandle->voiceLibHandle, "RK_VOICE_ProcessTx");
    pHandle->voiceApi->processPlayback = (PFNRX)dlsym(pHandle->voiceLibHandle, "RK_VOICE_ProcessRx");
    pHandle->voiceApi->deinit= (PFNDEINIT)dlsym(pHandle->voiceLibHandle, "RK_VOICE_Destory");
    if ((pHandle->voiceApi->init == NULL)
        || (pHandle->voiceApi->processCapture == NULL)
        || (pHandle->voiceApi->processPlayback == NULL)
        || (pHandle->voiceApi->deinit == NULL)) {
        ALOGE("dlsym voice process lib failed, return");
        goto failed;
    }
    // init the voice process lib
    int ret = 0;
    ret = pHandle->voiceApi->init(param_path);
    ALOGD("voice api init ret = %d", ret);
    if (ret != 0) {
        if (pHandle->voiceApi->lasterror) {
            pHandle->voiceApi->lasterror(error_buf, sizeof(error_buf));
        }
        ALOGE("init %s failed, ret = %d last error:%s", param_path, ret, error_buf);
        goto failed;
    }

    // init the processApi interface
    pHandle->processApi = (rk_process_api *)malloc(sizeof(rk_process_api));
    pHandle->processApi->start = start;
    pHandle->processApi->getCapureBuffer = getCapureBuffer;
    pHandle->processApi->getPlaybackBuffer = getPlaybackBuffer;
    pHandle->processApi->queuePlaybackBuffer = queuePlaybackBuffer;
    pHandle->processApi->quueCaputureBuffer = queueCaputureBuffer;
    pHandle->processApi->flush = flush;

    // malloc process buffers
    pHandle->playBackBuffer = (char *)malloc(MAX_BUFFER_SIZE);
    pHandle->captureBuffer = (char *)malloc(MAX_BUFFER_SIZE);
    pHandle->outPlayBuffer = (char *)malloc(MAX_BUFFER_SIZE);
    pHandle->outCaptureBuffer = (char *)malloc(MAX_BUFFER_SIZE);

    if ((pHandle->playBackBuffer == NULL) || (pHandle->captureBuffer == NULL)
        ||(pHandle->outPlayBuffer == NULL) || (pHandle->outCaptureBuffer == NULL)) {
        ALOGE("malloc playback or capure buffer falied!");
        goto failed;
    }

    pthread_mutex_init(&pHandle->voice_thread.queuePlyLock, NULL);
    pthread_mutex_init(&pHandle->voice_thread.queueCapLock, NULL);
    pthread_mutex_init(&pHandle->voice_thread.getCapOutLock, NULL);
    pthread_mutex_init(&pHandle->voice_thread.getPlyOutLock, NULL);

    if (pHandle->captureInSamplerate != pHandle->processSamplerate) {
        pHandle->speexCapureDownResample = speex_resampler_init(1, pHandle->captureInSamplerate, pHandle->processSamplerate, SPEEX_RESAMPLER_QUALITY_DESKTOP, NULL);
        pHandle->speexCapureUpResample = speex_resampler_init(1, pHandle->processSamplerate, pHandle->captureInSamplerate, SPEEX_RESAMPLER_QUALITY_DESKTOP, NULL);
    }

    if (pHandle->playbackInSamplerate!= pHandle->processSamplerate) {
        pHandle->speexPlaybackDownResample = speex_resampler_init(1, pHandle->playbackInSamplerate, pHandle->processSamplerate, SPEEX_RESAMPLER_QUALITY_DESKTOP, NULL);
        pHandle->speexPlaybackUpResample = speex_resampler_init(1, pHandle->processSamplerate, pHandle->playbackInSamplerate, SPEEX_RESAMPLER_QUALITY_DESKTOP, NULL);
    }
	ALOGD("rk 3a context create successfully!!!");
    pHandle->init = 1;
    return pHandle->processApi;
failed :
    rk_voiceprocess_destory();
	ALOGD("rk 3a context create fail!!!");
    return NULL;
}


int rk_voiceprocess_destory()
{
    rk_voice_handle *pHandle = getHandle();

    ALOGD("rk 3a context destory");
    if (pHandle == NULL) {
        ALOGD("rk 3a context destory return");
        return 0;
    }
    if (pHandle->voice_thread.threadStatus >= 0) {
        pHandle->voice_thread.running = false;
        sem_post(&pHandle->voice_thread.sem);
        ALOGD("join thread in");
        pthread_join(pHandle->voice_thread.thread, NULL);
        pHandle->voice_thread.threadStatus = -1;
        ALOGD("join thread out");

        sem_destroy(&pHandle->voice_thread.sem);
    }

    if (pHandle->speexCapureDownResample) {
        speex_resampler_destroy(pHandle->speexCapureDownResample);
        pHandle->speexCapureDownResample = NULL;
    }

    if (pHandle->speexCapureDownResample) {
        speex_resampler_destroy(pHandle->speexCapureDownResample);
        pHandle->speexCapureDownResample = NULL;
    }

    if (pHandle->speexPlaybackUpResample) {
        speex_resampler_destroy(pHandle->speexPlaybackUpResample);
        pHandle->speexPlaybackUpResample = NULL;
    }

    if (pHandle->speexPlaybackDownResample) {
        speex_resampler_destroy(pHandle->speexPlaybackDownResample);
        pHandle->speexPlaybackDownResample = NULL;
    }

    if (pHandle->playBackBuffer != NULL) {
        pthread_mutex_lock(&pHandle->voice_thread.queuePlyLock);
        free(pHandle->playBackBuffer);
        pHandle->playBackBuffer = NULL;
        pHandle->playbackBufferSize = 0;
        pthread_mutex_unlock(&pHandle->voice_thread.queuePlyLock);
    }

    if (pHandle->captureBuffer != NULL) {
        pthread_mutex_lock(&pHandle->voice_thread.queueCapLock);
        free(pHandle->captureBuffer);
        pHandle->captureBuffer = NULL;
        pHandle->captureBufferSize = 0;
        pthread_mutex_unlock(&pHandle->voice_thread.queueCapLock);
    }

    if (pHandle->outPlayBuffer != NULL) {
        pthread_mutex_lock(&pHandle->voice_thread.getPlyOutLock);
        free(pHandle->outPlayBuffer);
        pHandle->outPlayBuffer = NULL;
        pHandle->outPlaybackBufferSize = 0;
        pthread_mutex_unlock(&pHandle->voice_thread.getPlyOutLock);
    }

    if (pHandle->outCaptureBuffer != NULL) {
        pthread_mutex_lock(&pHandle->voice_thread.getCapOutLock);
        free(pHandle->outCaptureBuffer);
        pHandle->outCaptureBuffer = NULL;
        pHandle->outCaptureBufferSize = 0;
        pthread_mutex_unlock(&pHandle->voice_thread.getCapOutLock);
    }

    if (pHandle->processApi) {
        free(pHandle->processApi);
        pHandle->processApi = NULL;
    }

    if (pHandle->init) {
        if (pHandle->voiceApi) {
            pHandle->voiceApi->deinit();
        }
        pHandle->init = 0;
    }

    if (pHandle->voiceApi != NULL) {
        free(pHandle->voiceApi);
        pHandle->voiceApi = NULL;
    }
    if (pHandle->voiceLibHandle != NULL) {
        dlclose(pHandle->voiceLibHandle);
        pHandle->voiceLibHandle = NULL;
    }
    pHandle->init = 0;
    ALOGD("rk 3a context destory finish!");
    return 0;
}


static int processBuffertoMono(void *buffer, int size)
{
    short *in = (short *)buffer;
    short out[size/4];
    int i = 0, j = 0;

    for(i = 0, j = 0; i < size/4; i++) {
        out[i] = (in[j] + in[j+1]) / 2;
        j+=2;
    }
    memset((char *)in, 0x00, size);
    memcpy((char *)in, (char *)out, size/2);
    return 0;
}

static int processBuffertoStereo(void *buffer, int size)
{
    short *in = (short *)buffer;
    short out[size];
    int i = 0,j = 0;

    for (i = 0, j = 0; i < size/2; i++) {
        out[j] = in[i];
        out[j+1] = in[i];
        j+=2;
    }
    memcpy((char *)in, (char *)out, size * 2);
    return 0;
}


static void thread_loop(rk_voice_handle *handle)
{
    int playback_samplerate = handle->playbackInSamplerate;
    int capture_samplerate = handle->captureInSamplerate;
    int process_samplerate = handle->processSamplerate;
    int playback_channel = handle->playbackInChannels;
    int capture_channel = handle->captureInChannels;
    int process_buffer_size = handle->processBuffersize;
    int playback_min_buffersize = handle->minPlaybackBuffersize;
    int capture_min_buffersize = handle->minCaptureBuffersize;


    char tmp_capture_buffer[capture_min_buffersize];
    char tmp_capture_resampled_buffer[process_buffer_size];
    char tmp_outcapture_buffer[process_buffer_size];
    /*  process info for record:
     *  buffer pool --> tmp_capture_buffer --> convert(8K/16K)
     *  --> tmp_capture_resampled_buffer --> 3A proccess
     *  --> tmp_outcapture_buffer --> tmp_capture_buffer --> user
     */

    char tmp_playback_buffer[playback_min_buffersize];
    char tmp_playback_resampled_buffer[process_buffer_size];
    char tmp_outplayback_buffer[process_buffer_size];
    /*  process info for playback:
     *  buffer pool --> tmp_playback_buffer --> convert(8K/16K)
     *  --> tmp_playback_resampled_buffer --> 3A proccess
     *  --> tmp_outplayback_buffer --> tmp_capture_buffer --> hw
     */

#ifdef ALSA_3A_DEBUG //please touch each file first
    in_capture_debug = fopen("/data/3a_capture_in.pcm", "wb");
    out_capture_debug = fopen("/data/3a_capture_out.pcm", "wb");
    in_playback_debug = fopen("/data/3a_playback_in.pcm", "wb");
    out_playback_debug = fopen("/data/3a_playback_out.pcm", "wb");
#endif
    ALOGD_3A("rk 3a process start...");
    ALOGD_3A("info min buffer size playback:%d capture:%d process:%d",
             playback_min_buffersize,
             capture_min_buffersize,
             process_buffer_size);

    while (handle->voice_thread.running) {
        bool isGetBuffer = false;
        //wait the enough raw buffer
        if ((handle->captureBufferSize < capture_min_buffersize) || (handle->playbackBufferSize < playback_min_buffersize)) {
            sem_wait(&handle->voice_thread.sem);
        }

        char value[PROPERTY_VALUE_MAX] = "";
        property_get("media.audio.record", value, NULL);
        prop_pcm_record = atoi(value);

        // try to get the raw buffer to process
        if ((handle->captureBufferSize >= capture_min_buffersize) && (handle->playbackBufferSize >= playback_min_buffersize)) {
            pthread_mutex_lock(&handle->voice_thread.queueCapLock);
            memcpy(tmp_capture_buffer, handle->captureBuffer, capture_min_buffersize);
            memcpy(handle->captureBuffer, handle->captureBuffer+capture_min_buffersize, MAX_BUFFER_SIZE-capture_min_buffersize);
            handle->captureBufferSize -= capture_min_buffersize;
            pthread_mutex_unlock(&handle->voice_thread.queueCapLock);

            pthread_mutex_lock(&handle->voice_thread.queuePlyLock);
            memcpy(tmp_playback_buffer, handle->playBackBuffer, playback_min_buffersize);
            memcpy(handle->playBackBuffer, handle->playBackBuffer+playback_min_buffersize, MAX_BUFFER_SIZE-playback_min_buffersize);
            handle->playbackBufferSize -= playback_min_buffersize;
            pthread_mutex_unlock(&handle->voice_thread.queuePlyLock);
            isGetBuffer = true;
        }

        // process the raw buffer and queue to output list
        if (isGetBuffer) {
            // process buffer to mono
            if (playback_channel > 1) {
                processBuffertoMono(tmp_playback_buffer, playback_min_buffersize);
            }

            if (capture_channel > 1) {
                processBuffertoMono(tmp_capture_buffer, capture_min_buffersize);
            }

            // resample raw buffer to processed samplerate
            if (playback_samplerate != process_samplerate) {
                int in_sample = handle->nPlaybackExtFrameCount;
                int out_sample = handle->nProcessFrameCount;
                memset(tmp_playback_resampled_buffer, 0x00, process_buffer_size);
                speex_resampler_process_interleaved_int(handle->speexPlaybackDownResample,
                                                        (spx_int16_t *)tmp_playback_buffer, &in_sample,
                                                        (spx_int16_t *)tmp_playback_resampled_buffer, &out_sample);
            }

            if (capture_samplerate != process_samplerate) {
                int in_sample = handle->nCauptureExtFrameCount;
                int out_sample = handle->nProcessFrameCount;
                memset(tmp_capture_resampled_buffer, 0x00, process_buffer_size);
                speex_resampler_process_interleaved_int(handle->speexCapureDownResample,
                                                        (spx_int16_t *)tmp_capture_buffer, &in_sample,
                                                        (spx_int16_t *)tmp_capture_resampled_buffer, &out_sample);
            }

            // main process call
            if (handle->voiceApi) {
                handle->voiceApi->processPlayback((short *)tmp_playback_resampled_buffer,
                                                  (short *)tmp_outplayback_buffer,
                                                  handle->nProcessFrameCount);
                handle->voiceApi->processCapture((short *)tmp_capture_resampled_buffer,
                                                 (short *)tmp_outplayback_buffer,
                                                 (short *)tmp_outcapture_buffer,
                                                 handle->nProcessFrameCount);
#ifdef ALSA_3A_DEBUG
                fwrite(tmp_capture_resampled_buffer, sizeof(short), handle->nProcessFrameCount, in_capture_debug);
                fwrite(tmp_outcapture_buffer, sizeof(short), handle->nProcessFrameCount, out_capture_debug);
                fwrite(tmp_playback_resampled_buffer, sizeof(short), handle->nProcessFrameCount, in_playback_debug);
                fwrite(tmp_outplayback_buffer, sizeof(short), handle->nProcessFrameCount, out_playback_debug);
#endif
            }

            // upresample the processed buffer to raw buffer samplerate
            if (playback_samplerate != process_samplerate) {
                int in_sample = handle->nProcessFrameCount;
                int out_sample = handle->nPlaybackExtFrameCount;
                memset(tmp_playback_buffer, 0x00, playback_min_buffersize);
                speex_resampler_process_interleaved_int(handle->speexPlaybackUpResample,
                                                        (spx_int16_t *)tmp_outplayback_buffer, &in_sample,
                                                        (spx_int16_t *)tmp_playback_buffer, &out_sample);

            }

            if (capture_samplerate != process_samplerate) {
                int in_sample = handle->nProcessFrameCount;
                int out_sample = handle->nCauptureExtFrameCount;
                memset(tmp_capture_buffer, 0x00, capture_min_buffersize);
                speex_resampler_process_interleaved_int(handle->speexCapureUpResample,
                                                        (spx_int16_t *)tmp_outcapture_buffer, &in_sample,
                                                        (spx_int16_t *)tmp_capture_buffer, &out_sample);
            }

            // up adjust channel to raw buffer channels
            if (playback_channel > 1) {
                processBuffertoStereo(tmp_playback_buffer, playback_min_buffersize/2);
            }

            if (capture_channel > 1) {
                processBuffertoStereo(tmp_capture_buffer, capture_min_buffersize/2);
            }

            // queue processed buffer to output list
            pthread_mutex_lock(&handle->voice_thread.getCapOutLock);
            memcpy((char *)handle->outCaptureBuffer + handle->outCaptureBufferSize,tmp_capture_buffer, capture_min_buffersize);
            handle->outCaptureBufferSize += capture_min_buffersize;
            pthread_mutex_unlock(&handle->voice_thread.getCapOutLock);
            pthread_mutex_lock(&handle->voice_thread.getPlyOutLock);
            memcpy((char *)handle->outPlayBuffer + handle->outPlaybackBufferSize, tmp_playback_buffer, playback_min_buffersize);
            handle->outPlaybackBufferSize += playback_min_buffersize;
            pthread_mutex_unlock(&handle->voice_thread.getPlyOutLock);
        }
    }
#ifdef ALSA_3A_DEBUG
    fclose(in_capture_debug);
    fclose(out_capture_debug);
    fclose(in_playback_debug);
    fclose(out_playback_debug);
#endif
}

static void*  thread_start(void *argv)
{
    rk_voice_handle *handle = (rk_voice_handle *)argv;

    thread_loop(handle);
    ALOGD_3A("rk 3a process exit...");
    return NULL;
}

